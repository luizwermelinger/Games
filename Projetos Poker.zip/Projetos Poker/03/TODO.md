# TO-DO list for future releases

- [ ] CSS modernization / theming
- [ ] Cookie to locally store highscore
- [ ] GitHub Pages page
- [ ] Keyboard / Directional keys or pad support
- [ ] Scale display to fill the HTML window
- [ ] Card deal and flipping animation
- [ ] Animation when a row/column is filled
- [ ] Sound effects for events and ambient
- [ ] Vertical, mobile-oriented layout
- [ ] Electron or equivalent, for a standalone version
- [ ] Roku version
- [ ] Android version
