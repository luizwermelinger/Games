# simply-simple-poker
This is a simple poker game created for javascript practice and fun.
