# javascript-video-poker-game
A video poker game made with javascript, jquery, css, and html

I created this project to practice javascript and jquery. It's a fairly simple program but fully functional. 

new version located at https://github.com/Tweety79rw/Ryans-Stuff/tree/master/HttpPage/src/main/resources/static
